# دليل البدء

1. نزّل المجلد المشترك `ccc-platform`.
2. ارفع محتوياته إلى مستودع GitHub خاص.
3. لا ترفع ملفات الأسرار مثل `.env` أو `terraform.tfvars`.
4. بعد تجهيز Google Cloud نستخدم ملفات `infra/terraform`.
5. ملف `docker/docker-compose.yml` للتشغيل المحلي فقط.

يجب أن ترى في جذر المجلد: `README.md` و`apps/` و`infra/` و`docker/` و`docs/` و`.github/`.
