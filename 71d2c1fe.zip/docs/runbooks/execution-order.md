# ترتيب الملفات

1. `README.md`
2. `docs/`
3. `infra/terraform/`
4. `apps/ccc-mock-partners/`
5. `apps/ccc-core/`
6. `apps/ccc-web/`
7. `docker/docker-compose.yml`
8. `.github/workflows/`
